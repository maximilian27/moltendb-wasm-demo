# @moltendb/query

Type-safe, chainable query builder for [MoltenDB](https://github.com/maximilian27/MoltenDB).

Works in vanilla JavaScript and TypeScript. Compiles as an npm module (CJS + ESM + `.d.ts`).

---

## Installation

```bash
npm install @moltendb/query
```

---

## Quick start

```ts
import { MoltenDBClient, WorkerTransport } from '@moltendb/query';

// Connect to a MoltenDB WASM Web Worker
const worker = new Worker('./moltendb-worker.js', { type: 'module' });
const db = new MoltenDBClient(new WorkerTransport(worker));

// GET — query with WHERE, field projection, sort and pagination
const results = await db.collection('laptops')
  .get()
  .where({ brand: 'Apple' })
  .fields(['brand', 'model', 'price'])
  .sort([{ field: 'price', order: 'asc' }])
  .count(5)
  .exec();

// SET — insert / upsert
await db.collection('laptops')
  .set({
    lp1: { brand: 'Lenovo', model: 'ThinkPad X1', price: 1499, in_stock: true },
    lp2: { brand: 'Apple',  model: 'MacBook Pro',  price: 3499, in_stock: true },
  })
  .exec();

// UPDATE — partial patch (only listed fields are changed)
await db.collection('laptops')
  .update({ lp4: { price: 1749, in_stock: true } })
  .exec();

// DELETE — single key
await db.collection('laptops').delete().keys('lp6').exec();

// DELETE — batch
await db.collection('laptops').delete().keys(['lp4', 'lp5']).exec();

// DELETE — drop entire collection
await db.collection('laptops').delete().drop().exec();
```

---

## Operations & allowed fields

Each operation only exposes the methods that are valid for it — invalid
combinations are caught at compile time by TypeScript.

### `get()` — read / query

| Method | Description |
|---|---|
| `.keys(key \| key[])` | Fetch one or more documents by key |
| `.where(clause)` | Filter with operators: `$eq $ne $gt $gte $lt $lte $in $nin $contains` |
| `.fields(string[])` | Return only these fields (dot-notation supported) |
| `.excludedFields(string[])` | Return everything except these fields |
| `.joins(JoinSpec[])` | Embed related documents from other collections |
| `.sort(SortSpec[])` | Sort results (multi-field, asc/desc) |
| `.count(n)` | Limit results to N documents |
| `.offset(n)` | Skip first N results (pagination) |
| `.build()` | Return the raw JSON payload without sending |
| `.exec()` | Send the query and return the result |

### `set(data)` — insert / upsert

| Method | Description |
|---|---|
| `.extends(map)` | Embed snapshots from other collections at insert time |
| `.build()` | Return the raw JSON payload without sending |
| `.exec()` | Send and return `{ count, status }` |

`data` can be a `{ key: document }` map or a `Document[]` array (UUIDv7 keys are auto-assigned for arrays).

### `update(data)` — partial patch

| Method | Description |
|---|---|
| `.build()` | Return the raw JSON payload without sending |
| `.exec()` | Send and return `{ count, status }` |

Only the fields present in each patch object are updated — all other fields are left unchanged.

### `delete()` — delete documents or drop collection

| Method | Description |
|---|---|
| `.keys(key \| key[])` | Delete one or more documents by key |
| `.drop()` | Drop the entire collection |
| `.build()` | Return the raw JSON payload without sending |
| `.exec()` | Send and return `{ count, status }` |

---

## WHERE operators

```ts
// Exact equality (implicit)
.where({ brand: 'Apple' })

// Comparison
.where({ price: { $gt: 1000, $lt: 3000 } })
.where({ 'specs.cpu.cores': { $gte: 12 } })

// Not equal
.where({ 'specs.cpu.brand': { $ne: 'Intel' } })

// In / not-in list
.where({ brand: { $in: ['Apple', 'Dell'] } })
.where({ brand: { $nin: ['Framework'] } })

// Contains (string substring or array element)
.where({ model: { $contains: 'Pro' } })
.where({ tags:  { $contains: 'gaming' } })

// Multiple conditions (implicit AND)
.where({ in_stock: true, 'specs.cpu.brand': 'Intel' })
```

---

## Joins

```ts
const results = await db.collection('laptops')
  .get()
  .fields(['brand', 'model', 'price'])
  .joins([
    { alias: 'ram',    from: 'memory',  on: 'memory_id',  fields: ['capacity_gb', 'type'] },
    { alias: 'screen', from: 'display', on: 'display_id', fields: ['refresh_hz', 'panel'] },
  ])
  .exec();
// Each result: { brand, model, price, ram: { capacity_gb, type }, screen: { refresh_hz, panel } }
```

---

## Extends (snapshot embedding at insert time)

```ts
await db.collection('laptops')
  .set({
    lp7: {
      brand: 'MSI', model: 'Titan GT77', price: 3299,
      specs: { cpu: { brand: 'Intel', cores: 16, ghz: 5.0 } },
    },
  })
  .extends({ ram: 'memory.mem4', screen: 'display.dsp3' })
  .exec();
// lp7 is stored with the full mem4 and dsp3 documents embedded inline.
```

---

## Custom transport

Implement `MoltenTransport` to connect to any backend:

```ts
import { MoltenTransport, MoltenDBClient, Document, JsonValue } from '@moltendb/query';

class FetchTransport implements MoltenTransport {
  constructor(private baseUrl: string, private token: string) {}

  async send(action: 'get' | 'set' | 'update' | 'delete', payload: Document): Promise<JsonValue> {
    const res = await fetch(`${this.baseUrl}/${action}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`,
      },
      body: JSON.stringify(payload),
    });
    return res.json();
  }
}

const db = new MoltenDBClient(new FetchTransport('https://localhost:1538', myToken));
```

---

## Build

```bash
npm run build      # emit dist/index.js (CJS), dist/index.esm.js (ESM), dist/index.d.ts
npm run typecheck  # type-check without emitting
```

---

## License

MIT OR Apache-2.0
